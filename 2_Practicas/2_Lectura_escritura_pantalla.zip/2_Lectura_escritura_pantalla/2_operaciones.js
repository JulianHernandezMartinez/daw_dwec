'use strict'
console.log('Hola Operaciones a Piñon fijo!');

const h1 = document.querySelector('#h1');
h1.textContent = 'Operaciones a piñon fijo realizadas';
